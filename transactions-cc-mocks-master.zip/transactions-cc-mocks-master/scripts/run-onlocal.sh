#!/bin/sh
cd ../data/
java -jar ./wiremock-jre8-standalone-2.32.0.jar --enable-stub-cors


