cd ..
docker build -t wiremockimage:latest .
docker rm -f $(docker ps -a -q)
docker run -it --rm -d -p 8080:8080 --name wiremockcontainer wiremockimage:latest --enable-stub-cors

